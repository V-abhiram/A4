class Column extends React.Component {
  render() {
    return(
      <div className="col">
        {this.props.value}
      </div>
    )
  }
}
