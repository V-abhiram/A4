ReactDOM.render(
  <CourseList />,
  document.getElementById('root')
)
